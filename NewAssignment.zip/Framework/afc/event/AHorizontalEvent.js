
/**
 * 
 */

class AHorizontalEvent extends AEvent
{
	constructor(acomp)
	{
		super(acomp);
	}

}
window.AHorizontalEvent = AHorizontalEvent;


