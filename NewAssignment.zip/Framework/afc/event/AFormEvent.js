
/**
 * @author asoocool
 */
 


class AFormEvent extends AViewEvent
{
	constructor(acomp)
	{
		super(acomp);
	}
}
window.AFormEvent = AFormEvent;



//---------------------------------------------------------------------------------------------------
//	Component Event Functions





//---------------------------------------------------------------------------------------------------




