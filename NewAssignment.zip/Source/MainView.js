
class MainView extends AView
{
	constructor()
	{
		super()        

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)
	}

	onInitDone()
	{
		super.onInitDone()
        
        this.infiniteRolling();
    }

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)
	}

    infiniteRolling() {
        const rollingAreaEl = this.rollingArea.getElement();
        
        setInterval(() => {

            rollingAreaEl.style.transform = 'translateY(100px)';
            rollingAreaEl.style.transition = 'transform 1.5s ease-in';
        }, 400);
    }

}

/**
 *  클래스 안에는 function이 없음.
 *  스젠 3에는 function이 있음.
 *  
 *  왜 Why? 스젠 3의 cls파일은 class가 닫히고 다음 로직이 나오는데
 *  스젠 5는 클래스 안에서 작성됨.
 */

/**
 *  자동으로 rolling이 되어야 하니까
 *  함수 만들어서 onInitDone()에서 호출
 *  그러면 실행되자마자 rolling
 * 
 *  Java처럼 return값 줘야 함
 *    => React 형식으로 return(안에 로직 작성);해서 보내도 좋을 듯
 */

/**
 *  호출 시 함수를 변수처럼 보내면 함수 자체가 뜨고
 *         ()로 함수를 명시해주면 결과 값이 뜨는 듯 <== 추정
 */